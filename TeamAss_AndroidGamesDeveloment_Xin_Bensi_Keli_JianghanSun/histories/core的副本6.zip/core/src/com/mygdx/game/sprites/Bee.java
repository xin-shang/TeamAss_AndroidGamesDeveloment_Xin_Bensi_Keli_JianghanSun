package com.mygdx.game.sprites;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

/**
 * Sprite of bee, hold the texture
 */
public class Bee extends Sprite implements SpriteUpdateAdapter{

    private static Texture textureSheet;
    private static Animation<TextureRegion> animation;
    private static final int REG_COL = 2;
    private static final int REG_ROW = 1;
    private static final String TEX_PATH = "bee.png";
    private static TextureRegion textureRegions[];

    static {
        textureSheet = new Texture(TEX_PATH);
        TextureRegion[][] split = TextureRegion.split(textureSheet, textureSheet.getWidth() / REG_COL, textureSheet.getHeight() / REG_ROW);
        textureRegions = new TextureRegion[REG_ROW * REG_COL];
        int regionIndex = 0;
        for (int i = 0; i < REG_ROW; i++) {
            for (int j = 0; j < REG_COL; j++) {
                textureRegions[regionIndex++] = split[i][j];
            }
        }
        animation = new Animation<TextureRegion>(0.5f, textureRegions);
    }

    private final float initX;


    private float currentTime = 0;


    /**
     * reset sprite current time
     */
    public void reset(){
        currentTime = 0;
    }

    /**
     * update by delta
     * @param delta time delta
     */
    @Override
    public void update(float delta) {
        currentTime += delta;
        setX(initX - currentTime * 150);
        // update animation
        setRegion(animation.getKeyFrame(currentTime, true));
    }

    /**
     * create a bee sprite at x,y
     * @param x position x
     * @param y position y
     */
    public Bee(float x, float y) {
        super(animation.getKeyFrame(0));
        this.initX = x;
        setPosition(x,y);
    }

    /**
     * get collision rectangle by default bounding rect
     * @return
     */
    public Rectangle getCollisionRect() {
        return getBoundingRectangle();
    }
}
