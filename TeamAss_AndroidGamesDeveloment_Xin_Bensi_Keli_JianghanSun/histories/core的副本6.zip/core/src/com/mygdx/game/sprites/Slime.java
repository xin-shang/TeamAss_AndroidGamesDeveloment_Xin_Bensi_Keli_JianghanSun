package com.mygdx.game.sprites;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

/**
 * slime sprite
 */
public class Slime extends Sprite implements SpriteUpdateAdapter{

    // textures
    private static Texture textureSheet;
    private static Animation<TextureRegion> animation;
    private static final int REG_COL = 2;
    private static final int REG_ROW = 1;
    private static final String TEX_PATH = "slime.png";
    private static TextureRegion textureRegions[];

    // animation load
    static {
        textureSheet = new Texture(TEX_PATH);
        TextureRegion[][] split = TextureRegion.split(textureSheet, textureSheet.getWidth() / REG_COL, textureSheet.getHeight() / REG_ROW);
        textureRegions = new TextureRegion[REG_ROW * REG_COL];
        int regionIndex = 0;
        for (int i = 0; i < REG_ROW; i++) {
            for (int j = 0; j < REG_COL; j++) {
                textureRegions[regionIndex++] = split[i][j];
            }
        }
        animation = new Animation<TextureRegion>(0.5f, textureRegions);
    }

    // init x for reset use
    private final float initX;


    private float currentTime = 0;


    public void reset(){
        currentTime = 0;
    }

    /**
     * update position
     * @param delta time delta
     */
    @Override
    public void update(float delta) {
        currentTime += delta;
        setX(initX - currentTime * 100);
        setRegion(animation.getKeyFrame(currentTime, true));
    }

    /**
     * generate a slime at x,y
     * @param x pos x
     * @param y pos y
     */
    public Slime(float x, float y) {
        super(animation.getKeyFrame(0));
        this.initX = x;
        setPosition(x,y);
    }

    /**
     * slime collision rect
     * @return collision rect use tmp
     */
    public Rectangle getCollisionRect() {
        Rectangle.tmp.x = getX();
        Rectangle.tmp.y = getY();
        Rectangle.tmp.width = 104;
        Rectangle.tmp.height = 57;
        return Rectangle.tmp;
    }
}
