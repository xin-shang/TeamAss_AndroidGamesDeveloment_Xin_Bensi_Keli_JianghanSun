package com.mygdx.game.stages;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mygdx.game.MyGdxGame;

public class Pause extends Stage {
    private final MyGdxGame game;
    private Image pauseBkg, btnPause;

    public Pause(final MyGdxGame game) {

        this.game = game;

        pauseBkg = new Image(new Texture(Gdx.files.internal("pause_bkg.png")));
        btnPause = new Image(new Texture(Gdx.files.internal("pause.png")));

        pauseBkg.setPosition(0, 0);
        btnPause.setPosition(650, 400);
        pauseBkg.setSize(800,480);
        btnPause.setSize(128,64);
        pauseBkg.setVisible(false);

        btnPause.setBounds(btnPause.getX(), btnPause.getY(), btnPause.getWidth(), btnPause.getHeight());

        btnPause.addListener((new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.pause();
                pauseBkg.setVisible(true);
                btnPause.setVisible(false);
            }
        }));

        pauseBkg.addListener((new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.resume();
                pauseBkg.setVisible(false);
                btnPause.setVisible(true);
            }
        }));

        addActor(pauseBkg);
        addActor(btnPause);
    }

    @Override
    public void act() {
        super.act();
    }
}
