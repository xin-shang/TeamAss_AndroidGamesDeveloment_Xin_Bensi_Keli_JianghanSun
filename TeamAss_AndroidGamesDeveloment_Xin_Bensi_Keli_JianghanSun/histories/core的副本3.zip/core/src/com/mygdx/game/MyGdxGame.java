package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.stages.*;

public class MyGdxGame extends ApplicationAdapter {


    enum StageState {
        MainMenu, Game, GameOver, GameWin,
    }

    StageState stageState = StageState.MainMenu;
    private static final int VIEWPORT_WIDTH = 800;
    private static final int VIEWPORT_HEIGHT = 480;
    Viewport viewport;

   boolean isPaused;
    GameScreen stageGame;
    MainMenu stageMainMenu;
    Win stageWin;
    Gameover stageGameOver;
    Pause stagePause;

    public void startGame() {
        stageGame.reload();
        InputMultiplexer inputMultiplexer = new InputMultiplexer(stagePause, stageGame);
        Gdx.input.setInputProcessor(inputMultiplexer);
        stageState = StageState.Game;
    }

    public void title() {
        Gdx.input.setInputProcessor(stageMainMenu);
        stageState = StageState.MainMenu;
    }

    public void failed() {
        Gdx.input.setInputProcessor(stageGameOver);
        stageState = StageState.GameOver;
    }

    @Override
    public void pause() {
        super.pause();
        isPaused = true;
    }

    @Override
    public void resume() {
        isPaused = false;
        super.resume();
    }

    public void winGame() {
        Gdx.input.setInputProcessor(stageWin);
        stageState = StageState.GameWin;
    }

    @Override
    public void create() {
        OrthographicCamera gameStageCamera = new OrthographicCamera();
        viewport = new FitViewport(VIEWPORT_WIDTH, VIEWPORT_HEIGHT, gameStageCamera);

        stagePause = new Pause(this);
        stageGame = new GameScreen("level1.tmx", gameStageCamera, this);
        stageGameOver = new Gameover(this);
        stageWin = new Win(this);
        stageMainMenu = new MainMenu(this);

        Gdx.input.setInputProcessor(stageMainMenu);

    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
    }

    @Override
    public void render() {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        float deltaTime = Gdx.graphics.getDeltaTime();

        if (stageState == StageState.MainMenu) {
            stageMainMenu.act(deltaTime);
            stageMainMenu.draw();
        }

        if (stageState == StageState.Game) {

            // actfirst
            stagePause.act(deltaTime);

            if(!isPaused) {
                stageGame.act(deltaTime);
                stageGame.draw();
            }

            stagePause.draw();
        }

        if (stageState == StageState.GameOver) {
            stageGameOver.act(deltaTime);
            stageGameOver.draw();
        }


        if (stageState == StageState.GameWin) {
            stageWin.act(deltaTime);
            stageWin.draw();

        }


    }


    @Override
    public void dispose() {
        stageMainMenu.dispose();
        stageGame.dispose();
        stageGameOver.dispose();
        stageWin.dispose();
    }
}
