package com.mygdx.game.stages;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.sprites.Bee;
import com.mygdx.game.sprites.Player;
import com.mygdx.game.sprites.Slime;

import java.util.LinkedList;
import java.util.List;

public class GameScreen extends Stage implements InputProcessor {
    private static final int VIEWPORT_WIDTH = 800;

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {

        if (screenY <  Gdx.graphics.getHeight() / 2) {
            spritePlayer.jump();
        } else {
            spritePlayer.slide();
        }
//        return super.touchDown(screenX, screenY, pointer, button);
        return false;
    }

    private static final int VIEWPORT_HEIGHT = 480;
    private static final int CAM_STARTUP_X = VIEWPORT_WIDTH / 2;
    private static final int CAM_STARTUP_Y = 580;
    private static final double SPEED = 360;
    private final MyGdxGame game;
    OrthographicCamera camera;
    OrthogonalTiledMapRenderer renderer;

    Player spritePlayer = new Player();
    List<Bee> spriteBees = new LinkedList<>();
    List<Slime> spriteSlimes = new LinkedList<>();

    float playerOffset = 0;

    @Override
    public void draw() {
        getBatch().begin();
        renderer.setView(camera);
        renderer.render();


        // draw bees
        for (Bee spriteBee : spriteBees) {
            spriteBee.draw(getBatch());
        }
        // draw slimes
        for (Slime spriteSlime : spriteSlimes) {
            spriteSlime.draw(getBatch());
        }

        spritePlayer.draw(getBatch());
        camera.update();
        getBatch().end();
    }

    double totalTime = 0;

    @Override
    public void act(float delta) {
        if (spritePlayer.getState() != Player.PlayerState.Dead) {
            totalTime += delta;

        } else {
            if (spritePlayer.getStateTime() > 2.0f) {
                game.failed();
            }
        }
        playerOffset = (float) (SPEED * totalTime);
        camera.position.x = (float) ((double)(VIEWPORT_WIDTH / 2.0f) + totalTime * SPEED);

        if (camera.position.x > 17000 - (VIEWPORT_WIDTH / 2.0f)) {
            camera.position.x = 17000 - (VIEWPORT_WIDTH / 2.0f);
        }
        spritePlayer.setPosition(playerOffset, spritePlayer.getY());

        spritePlayer.update(delta);

        for (Bee spriteBee : spriteBees) {
            spriteBee.update(delta);
            if (spriteBee.getCollisionRect().overlaps(spritePlayer.getCollisionRect())) {
                spritePlayer.dead();
            }
        }

        for (Slime spriteSlime : spriteSlimes) {
            spriteSlime.update(delta);
            if (spriteSlime.getCollisionRect().overlaps(spritePlayer.getCollisionRect())) {
                spritePlayer.dead();
            }
        }


        if (playerOffset > 17000) {
            game.winGame();
        }
    }

    private void loadEnemy(String map) {
        String enemyFileName = map.split("\\.")[0] + "_enemy.txt";
        String texts = Gdx.files.internal(enemyFileName).readString();
        String[] enemies = texts.split("\\n");
        if(enemies.length >= 1) {
            String[] pos = enemies[0].split(" ");
            for (String posText : pos) {
                if(posText.trim().length() > 0) {
                    spriteSlimes.add(new Slime(Integer.parseInt(posText.trim()), 420));
                }
            }
        }

        if(enemies.length >= 2) {
            String[] pos = enemies[1].split(" ");
            for (String posText : pos) {
                if(posText.trim().length() > 0) {
                    spriteBees.add(new Bee(Integer.parseInt(posText.trim()), 500));
                }
            }
        }
    }

    public GameScreen(String map, OrthographicCamera camera, final MyGdxGame game) {

        this.game = game;
        TiledMap tileMap = new TmxMapLoader().load(map);
        loadEnemy(map);
        this.camera = camera;
        camera.position.y = 580;
        camera.position.x = 0;
        renderer = new OrthogonalTiledMapRenderer(tileMap);
//        addListener(new ClickListener() {
//            @Override
//            public void clicked(InputEvent event, float x, float y) {
//                if (y > VIEWPORT_HEIGHT / 2) {
//                    spritePlayer.jump();
//                } else {
//                    spritePlayer.slide();
//                }
//            }
//        });



    }

    public boolean isDead() {
        return spritePlayer.getState() == Player.PlayerState.Dead;
    }
    public void reload() {
        totalTime = 0;
        camera.position.y = 580;
        camera.position.x = 0;
        spritePlayer.reset();
        for (Bee spriteBee : spriteBees) {
            spriteBee.reset();
        }

        for (Slime spriteSlime : spriteSlimes) {
            spriteSlime.reset();
        }
        playerOffset = 0;
    }
}
