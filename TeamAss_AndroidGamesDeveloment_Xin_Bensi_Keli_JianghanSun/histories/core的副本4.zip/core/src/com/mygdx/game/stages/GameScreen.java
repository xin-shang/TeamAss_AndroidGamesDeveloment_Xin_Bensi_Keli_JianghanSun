package com.mygdx.game.stages;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.sprites.Bee;
import com.mygdx.game.sprites.Player;
import com.mygdx.game.sprites.Slime;

import java.util.LinkedList;
import java.util.List;

public class GameScreen extends Stage {
    private static final int VIEWPORT_WIDTH = 800;
    private static final int VIEWPORT_HEIGHT = 480;
    private static final int CAM_STARTUP_X = VIEWPORT_WIDTH / 2;
    private static final int CAM_STARTUP_Y = 580;
    private static final float SPEED = 360.0f;
    private final MyGdxGame game;
    OrthographicCamera camera;
    OrthogonalTiledMapRenderer renderer;

    Player spritePlayer = new Player();
    List<Bee> spriteBees = new LinkedList<>();
    List<Slime> spriteSlimes = new LinkedList<>();

    float playerOffset = 0;

    @Override
    public void draw() {
        getBatch().begin();
        renderer.setView(camera);
        renderer.render();


        // draw bees
        for (Bee spriteBee : spriteBees) {
            spriteBee.draw(getBatch());
        }
        // draw slimes
        for (Slime spriteSlime : spriteSlimes) {
            spriteSlime.draw(getBatch());
        }

        spritePlayer.draw(getBatch());
        camera.update();
        getBatch().end();
    }

    @Override
    public void act(float delta) {
        if (spritePlayer.getState() != Player.PlayerState.Dead) {
            playerOffset += SPEED * delta;
        } else {
            if (spritePlayer.getStateTime() > 2.0f) {
                game.failed();
            }
        }
        camera.position.x = (VIEWPORT_WIDTH / 2.0f) + playerOffset;

        if (camera.position.x > 17000 - (VIEWPORT_WIDTH / 2.0f)) {
            camera.position.x = 17000 - (VIEWPORT_WIDTH / 2.0f);
        }
        spritePlayer.setPosition(playerOffset, spritePlayer.getY());

        spritePlayer.update(delta);

        for (Bee spriteBee : spriteBees) {
            spriteBee.update(delta);
            if (spriteBee.getCollisionRect().overlaps(spritePlayer.getCollisionRect())) {
                spritePlayer.dead();
            }
        }

        for (Slime spriteSlime : spriteSlimes) {
            spriteSlime.update(delta);
            if (spriteSlime.getCollisionRect().overlaps(spritePlayer.getCollisionRect())) {
                spritePlayer.dead();
            }
        }


        if (playerOffset > 17000) {
            game.winGame();
        }
    }

    private void loadEnemy(String map) {
        //mocked
        spriteSlimes.add(new Slime(1000, 420));
//        spriteSlimes.add(new Slime(2000, 420));
//        spriteSlimes.add(new Slime(3000, 420));
//        spriteSlimes.add(new Slime(4000, 420));
//        spriteSlimes.add(new Slime(4000, 420));
//        spriteSlimes.add(new Slime(5000, 420));
//        spriteSlimes.add(new Slime(6000, 420));
//        spriteSlimes.add(new Slime(7000, 420));
//        spriteSlimes.add(new Slime(9000, 420));
//        spriteSlimes.add(new Slime(10000, 420));
//        spriteSlimes.add(new Slime(11000, 420));
//        spriteSlimes.add(new Slime(12000, 420));
//        spriteSlimes.add(new Slime(13000, 420));
//        spriteSlimes.add(new Slime(14000, 420));
//        spriteSlimes.add(new Slime(15000, 420));
//        spriteSlimes.add(new Slime(16600, 420));
//        spriteSlimes.add(new Slime(16700, 420));

        spriteBees.add(new Bee(2000, 500));
    }

    public GameScreen(String map, OrthographicCamera camera, final MyGdxGame game) {

        this.game = game;
        TiledMap tileMap = new TmxMapLoader().load(map);
        loadEnemy(map);
        this.camera = camera;
        camera.position.y = 580;
        camera.position.x = 0;
        renderer = new OrthogonalTiledMapRenderer(tileMap);
        addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (y > VIEWPORT_HEIGHT / 2) {
                    spritePlayer.jump();
                } else {
                    spritePlayer.slide();
                }
            }
        });



    }

    public void reload() {
        camera.position.y = 580;
        camera.position.x = 0;
        spritePlayer.reset();
        for (Bee spriteBee : spriteBees) {
            spriteBee.reset();
        }

        for (Slime spriteSlime : spriteSlimes) {
            spriteSlime.reset();
        }
        playerOffset = 0;
    }
}
