package com.mygdx.game.sprites;

import com.badlogic.gdx.graphics.Camera;

public interface SpriteUpdateAdapter {
    void update(float delta);
}
