package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.stages.GameScreen;
import com.mygdx.game.stages.MainMenu;

public class MyGdxGame extends ApplicationAdapter {
	enum StageState{
		MainMenu, Game, GameOver
	}
	StageState stageState = StageState.MainMenu;
	private static final int VIEWPORT_WIDTH = 800;
	private static final int VIEWPORT_HEIGHT = 480;
	Viewport viewport;


	Stage stageGame;
	Stage stageMainMenu;

	public void startGame() {
		Gdx.input.setInputProcessor(stageGame);
		stageState = StageState.Game;
	}

	public void winGame() {
		
	}

	@Override
	public void create () {
		OrthographicCamera gameStageCamera = new OrthographicCamera();
		viewport = new FitViewport(VIEWPORT_WIDTH, VIEWPORT_HEIGHT,gameStageCamera);

		stageGame = new GameScreen("level1.tmx", gameStageCamera);

		stageMainMenu = new MainMenu(this);
		Gdx.input.setInputProcessor(stageMainMenu);

	}

	@Override
	public void resize(int width, int height) {
		viewport.update(width, height);
	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		float deltaTime = Gdx.graphics.getDeltaTime();

		if(stageState == StageState.MainMenu) {
			stageMainMenu.act(deltaTime);
			stageMainMenu.draw();
		}

		if(stageState == StageState.Game) {
			stageGame.act(deltaTime);
			stageGame.draw();
		}

	}


	@Override
	public void dispose () {
		stageMainMenu.dispose();
		stageGame.dispose();
	}
}
