package com.mygdx.game.stages;

public class Gameover {
}
