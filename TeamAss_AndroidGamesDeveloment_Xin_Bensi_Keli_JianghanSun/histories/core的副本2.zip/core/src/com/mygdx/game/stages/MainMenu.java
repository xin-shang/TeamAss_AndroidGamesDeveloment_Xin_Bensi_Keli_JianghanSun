package com.mygdx.game.stages;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mygdx.game.MyGdxGame;

public class MainMenu extends Stage {
    private final MyGdxGame game;
    private ShapeRenderer shapeRenderer;
    private Image btnStart, btnExit;

    @Override
    public void draw() {
        super.draw();
    }

    public MainMenu(final MyGdxGame game) {

        this.game = game;

        btnStart = new Image(new Texture(Gdx.files.internal("btnstart.png")));
        btnExit = new Image(new Texture(Gdx.files.internal("btnexit.png")));

        shapeRenderer = new ShapeRenderer();
        btnStart.setPosition(400 - 64, 290);
        btnExit.setPosition(400 - 64, 190);
        btnStart.setSize(128,64);
        btnExit.setSize(128,64);

        btnExit.setBounds(btnExit.getX(), btnExit.getY(), btnExit.getWidth(), btnExit.getHeight());
        btnStart.setBounds(btnStart.getX(), btnStart.getY(), btnStart.getWidth(), btnStart.getHeight());



        btnStart.addListener(( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.debug("DEBUG", "START GAME");
                game.startGame();
            }
        }));

        btnExit.addListener(( new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                System.exit(0);
            }
        }));

        addActor(btnStart);
        addActor(btnExit);
    }
}
