package com.mygdx.game.sprites;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import java.util.HashMap;
import java.util.Map;

public class Player extends Sprite implements SpriteUpdateAdapter {
    private static Texture textureSheet;

    enum PlayerState {
        Running,
        JumpingStart,
        JumpingEnd,
        SlidingStart,
        SlidingEnd,
        Dead,
    }

    PlayerState state = PlayerState.Running;
    float stateTime;
    private static Map<PlayerState, Animation<TextureRegion>> animations = new HashMap<>();

    private static final int[] REG_COLS = {4,3,2,2,1,3};
    private static final int[] REG_ROWS = {2,1,1,1,1,1};
    private static final float[] REG_DELTA = {0.1f, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f};
    private static final String[] TEXTURE_PATHS =
            {"running.png", "jumping start.png",
                    "jumping end.png", "sliding start.png", "sliding end.png", "deading.png"};

    static {
        for (PlayerState playerState : PlayerState.class.getEnumConstants()) {
            int index = playerState.ordinal();
            textureSheet = new Texture(TEXTURE_PATHS[index]);
            TextureRegion[][] split = TextureRegion.split(textureSheet, textureSheet.getWidth() / REG_COLS[index], textureSheet.getHeight() / REG_ROWS[index]);
            TextureRegion[] textureRegions = new TextureRegion[REG_ROWS[index] * REG_COLS[index]];
            int regionIndex = 0;
            for (int i = 0; i < REG_ROWS[index]; i++) {
                for (int j = 0; j < REG_COLS[index]; j++) {
                    textureRegions[regionIndex++] = split[i][j];
                }
            }
            animations.put(playerState, new Animation<TextureRegion>(REG_DELTA[index], textureRegions));
        }

    }



    @Override
    public void update(float delta) {
        stateTime += delta;
        if(this.state == PlayerState.JumpingStart) {
            if(this.stateTime >= 0.75f) {
                this.state = PlayerState.JumpingEnd;
                this.stateTime -= 0.75f;
            } else {
                this.setY(410 + (stateTime > 0.25? 0.25f * 600: stateTime * 600));
            }
        }

        if(this.state == PlayerState.JumpingEnd) {
            if(this.stateTime >= 0.25f) {
                this.state = PlayerState.Running;
                this.stateTime -= 0.25f;
                this.setY(410);
            } else {
                this.setY(560 - stateTime * 600);
            }
        }

        if(this.state == PlayerState.SlidingStart) {
            if(this.stateTime >= 0.5f) {
                this.state = PlayerState.SlidingEnd;
                this.stateTime -= 0.5f;
            }
        }

        if(this.state == PlayerState.SlidingEnd) {
            if(this.stateTime >= 0.25f) {
                this.state = PlayerState.Running;
                this.stateTime -= 0.25f;
            }
        }

        setRegion(animations.get(state).getKeyFrame(stateTime, state == PlayerState.Running));
        setSize(getRegionWidth(),getRegionHeight());
        setBounds(getX(),getY(),getWidth(),getHeight());
    }

    public Player() {
        super(animations.get(PlayerState.Running).getKeyFrame(0));
        // on the ground
        setY(410);
    }

    public void jump(){
        if(this.state != PlayerState.Running) return;
        this.stateTime = 0;
        this.state = PlayerState.JumpingStart;
    }

    public void slide(){
        if(this.state != PlayerState.Running) return;
        this.stateTime = 0;
        this.state = PlayerState.SlidingStart;
    }
}
