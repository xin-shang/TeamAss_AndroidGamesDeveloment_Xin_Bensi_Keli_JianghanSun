package com.mygdx.game.stages;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mygdx.game.sprites.Bee;
import com.mygdx.game.sprites.Player;
import com.mygdx.game.sprites.Slime;

import java.util.LinkedList;
import java.util.List;

public class GameScreen extends Stage {
    private static final int VIEWPORT_WIDTH = 800;
    private static final int VIEWPORT_HEIGHT = 480;
    private static final int CAM_STARTUP_X = VIEWPORT_WIDTH / 2;
    private static final int CAM_STARTUP_Y = 580;
    private static final float SPEED = 360.0f;
    OrthographicCamera camera;
    OrthogonalTiledMapRenderer renderer;

    Player spritePlayer = new Player();
    List<Bee> spriteBees = new LinkedList<>();
    List<Slime> spriteSlimes = new LinkedList<>();

    float playerOffset = 0;

    @Override
    public void draw() {
        getBatch().begin();
        renderer.setView(camera);
        renderer.render();


        // draw bees
        for (Bee spriteBee : spriteBees) {
            spriteBee.draw(getBatch());
        }
        // draw slimes
        for (Slime spriteSlime : spriteSlimes) {
            spriteSlime.draw(getBatch());
        }

		spritePlayer.draw(getBatch());
        camera.update();
        getBatch().end();
    }

    @Override
    public void act(float delta) {
        playerOffset += SPEED * delta;
        camera.position.x = (VIEWPORT_WIDTH / 2.0f) + playerOffset;

        if (camera.position.x > 17000 - (VIEWPORT_WIDTH / 2.0f)) {
            camera.position.x = 17000 - (VIEWPORT_WIDTH / 2.0f);
        }
        spritePlayer.setPosition(playerOffset, spritePlayer.getY());

        spriteSlimes.add(new Slime(4000, 420));

        for (Bee spriteBee : spriteBees) {
            spriteBee.update(delta);
        }

        for (Slime spriteSlime : spriteSlimes) {
			spriteSlime.update(delta);
        }

		spritePlayer.update(delta);

        if(playerOffset > 17000) {
            //CLEAR
        }
    }

    private void loadEnemy(String map) {
        //mocked

        spriteSlimes.add(new Slime(100, 420));
        spriteSlimes.add(new Slime(1000, 420));
        spriteSlimes.add(new Slime(2000, 420));
        spriteSlimes.add(new Slime(3000, 420));
        spriteSlimes.add(new Slime(4000, 420));
    }

    public GameScreen(String map, OrthographicCamera camera) {
        TiledMap tileMap = new TmxMapLoader().load(map);
        loadEnemy(map);
        this.camera = camera;
        camera.position.y = 580;
        camera.position.x = 0;
        renderer = new OrthogonalTiledMapRenderer(tileMap);
        addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if(y > VIEWPORT_HEIGHT / 2) {
                    spritePlayer.jump();
                } else {
                    spritePlayer.slide();
                }
            }
        });


    }
}
